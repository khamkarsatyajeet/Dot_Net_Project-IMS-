﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TS.EasyStockManager.Model.Domain
{
    public class CategoryDTO : BaseDTO
    {
        public string CategoryName { get; set; }
    }
}
