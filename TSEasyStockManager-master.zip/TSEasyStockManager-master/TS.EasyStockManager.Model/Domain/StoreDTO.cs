﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TS.EasyStockManager.Model.Domain
{
    public class StoreDTO : BaseDTO
    {
        public string StoreName { get; set; }
        public string StoreCode { get; set; }
    }
}
