﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TS.EasyStockManager.Core.Repository
{
    public interface ITransactionTypeRepository : IRepository<TS.EasyStockManager.Data.Entity.TransactionType>
    {
    }
}
