﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TS.EasyStockManager.Core.Repository
{
    public interface IUnitOfMeasureRepository : IRepository<TS.EasyStockManager.Data.Entity.UnitOfMeasure>
    {
    }
}
