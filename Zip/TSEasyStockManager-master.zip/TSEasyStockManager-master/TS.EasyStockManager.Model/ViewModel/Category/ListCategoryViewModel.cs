﻿using System;
using System.Collections.Generic;
using System.Text;
using TS.EasyStockManager.Model.ViewModel.Base;

namespace TS.EasyStockManager.Model.ViewModel.Category
{
    public class ListCategoryViewModel : BaseViewModel
    {
        public string CategoryName { get; set; }
    }
}
