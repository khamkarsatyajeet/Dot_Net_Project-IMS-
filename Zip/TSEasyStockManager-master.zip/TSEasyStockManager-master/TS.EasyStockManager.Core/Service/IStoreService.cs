﻿using System;
using System.Collections.Generic;
using System.Text;
using TS.EasyStockManager.Model.Domain;

namespace TS.EasyStockManager.Core.Service
{
    public interface IStoreService : IService<StoreDTO>
    {
    }
}
