﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TS.EasyStockManager.Data.Entity
{
    public class TransactionType : BaseEntity
    {
        public string TransactionTypeName { get; set; }
    }
}
